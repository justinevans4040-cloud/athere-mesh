# ARCHIVE — DCE Solar / Sara / Illinois Shines job materials

**Status:** ARCHIVED — job fell through. **Do not delete.**  
**Product now:** ForgeFront by Wake Industries (live app kept; this campaign copy removed from live UI).  
**Label date:** 2026-09-05  
**Why here:** Canonical ForgeFront vault project shelf (`02_PROJECTS`), beside other ForgeFront project recoveries — not a random dump.

## What this is

Materials for the **Sara / Illinois Shines / LightReach** campaign that were stripped from the live ForgeFront call-coach UI after the job fell through. Preserved so Justin can still market ForgeFront / solar tooling later without losing the campaign IP.

## Folders

| Folder | Contents |
|--------|----------|
| `01_JOB_PACKET_AND_SCRIPTS` | Sara packet HTML, IL Shines truth notes, noon pack, IL June scripts, packet builder |
| `02_PRE_WIPE_UI_AND_ENGINE_SNAPSHOT` | Full HTML + engine/copilot snapshot **before** campaign-copy wipe |
| `03_PRE_REBRAND_SNAPSHOT` | Snapshot before DCE → ForgeFront by Wake Industries rebrand |
| `04_RELATED_EXISTING_PACKAGES` | Related zip already on Ichabod home (`DCE_Command_Center_V3_Solar_V1_Audited-1.zip`) |
| `99_MANIFEST` | SHA-256 inventory |

## Also mirrored

- ForgeFront meta pointer + milestone under `~/forgefront/forgefront-meta/`
- Google Drive: `DCE_Command_Center_V3_Package/ARCHIVES/...` (same label)
- Git: labeled pointer commit in `athere-mesh` evidence (no secrets)

## Secrets policy

Portal token is **not** in this vault folder. Local-only: `forgefront-meta/secrets-local-only/`.
