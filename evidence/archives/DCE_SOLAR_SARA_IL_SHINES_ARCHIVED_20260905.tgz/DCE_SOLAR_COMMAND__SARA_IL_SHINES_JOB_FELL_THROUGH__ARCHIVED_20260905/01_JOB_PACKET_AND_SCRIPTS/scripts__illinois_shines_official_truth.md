# Illinois Shines — Official Program Truth

Source: [https://illinoisshines.com/about/](https://illinoisshines.com/about/) (fetched 2026-08-21)

## Safe facts for live coaching
- Illinois Shines = Adjustable Block Program (state program).
- Purpose: make solar more affordable (incentives, guidance, consumer protection, equity).
- Two main paths: **Distributed Generation** (on-site panels) and **Community Solar** (subscription / bill credits without owning panels).
- Incentives via **REC** payments to developers; value may reduce customer costs or appear as bill credits.
- 1 REC = 1 MWh renewable electricity added to the grid.
- Utilities purchase RECs under the Illinois RPS.
- Legal basis: FEJA 2016, expanded by CEJA 2021; supports 100% clean energy by 2050.
- Administered via IPA Long-Term Renewable Resources Procurement Plan.
- Consumer Protection Handbook applies to Approved Vendors / Designees.

## Claim gates
Do not invent: exact savings %, panel ownership, loan structure, utility “partnership” language, or LightReach terms unless in the current approved vendor packet.
