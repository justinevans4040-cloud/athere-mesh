#!/usr/bin/env python3
"""Auto-build Sara DCE packet HTML + portal invite + send sheet."""
from __future__ import annotations

import json
import re
import secrets
import time
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "DCE_SARA_PACKET.html"
ACCESS = ROOT / "dce_v3_access.json"
SCRIPTS = ROOT / "scripts"
STAMP = time.strftime("%Y-%m-%d %H:%M")


def strip_html(s: str) -> str:
    s = re.sub(r"<[^>]+>", " ", s)
    s = (
        s.replace("&apos;", "'")
        .replace("&quot;", '"')
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
    )
    return re.sub(r"\s+", " ", s).strip()


def extract_script_steps(html: str) -> list[tuple[str, str]]:
    steps: list[tuple[str, str]] = []
    for m in re.finditer(
        r'<div class="scriptStep"><h3>(.*?)</h3><p>(.*?)</p>(?:<div class="prompt">(.*?)</div>)?</div>',
        html,
        re.S,
    ):
        title = strip_html(m.group(1))
        body = strip_html(m.group(2))
        prompt = strip_html(m.group(3) or "")
        if prompt:
            body = f"{body} [{prompt}]"
        steps.append((title, body))
    return steps


def steps_html(steps: list[tuple[str, str]]) -> str:
    if not steps:
        return "<p class='muted'>Not loaded in live Command yet.</p>"
    bits = []
    for t, b in steps:
        bits.append(
            f"<div class='item'><b>{escape(t)}</b><span>{escape(b)}</span></div>"
        )
    return "<div class='list'>" + "".join(bits) + "</div>"


def section(title: str, body_html: str) -> str:
    return f"<section><h2>{escape(title)}</h2>{body_html}</section>"


def build_packet() -> str:
    v3 = (ROOT / "V3.html").read_text(encoding="utf-8", errors="ignore")
    sales: list[tuple[str, str]] = []
    rapport: list[tuple[str, str]] = []
    shines: list[tuple[str, str]] = []
    m = re.search(r"FULL SALES SCRIPT[\s\S]*?</details>", v3)
    if m:
        sales = extract_script_steps(m.group(0))
    m = re.search(r"FUNDAMENTALS OF RAPPORT[\s\S]*?</details>", v3)
    if m:
        rapport = extract_script_steps(m.group(0))
    m = re.search(r"ILLINOIS SHINES[\s\S]*?</details>", v3)
    if m:
        shines = extract_script_steps(m.group(0))

    docs = []
    for name in (
        "illinois_shines_official_truth.md",
        "rapport_fundamentals.md",
        "script_il_june_2026_sara.md",
    ):
        p = SCRIPTS / name
        if p.exists():
            docs.append(
                f"<h3>{escape(name)}</h3><pre class='doc'>{escape(p.read_text(encoding='utf-8')[:4500])}</pre>"
            )
    docs_html = "".join(docs) or "<p class='muted'>No markdown sources found.</p>"

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DCE Solar Command — Packet for Sara</title>
<style>
body{{margin:0;background:#0b1220;color:#eef5ff;font:15px/1.45 Inter,Segoe UI,system-ui,sans-serif}}
.wrap{{max-width:980px;margin:0 auto;padding:28px 18px 60px}}
.hero{{border:1px solid #24324a;background:linear-gradient(160deg,#121c31,#0d1526);border-radius:18px;padding:22px}}
.hero h1{{margin:0 0 8px;font:800 28px/1.15 Space Grotesk,Inter,sans-serif}}
.hero p{{margin:0;color:#9eb2c9}}
.badge{{display:inline-block;margin-top:12px;padding:6px 10px;border-radius:999px;border:1px solid #35507a;color:#9fd0ff;font-size:12px}}
section{{margin-top:16px;border:1px solid #24324a;background:#121a2b;border-radius:16px;padding:16px}}
section h2{{margin:0 0 10px;font:800 15px/1.2 Inter,sans-serif;letter-spacing:.04em;color:#ffb86b;text-transform:uppercase}}
.list{{display:grid;gap:8px}}
.item{{background:#0d1422;border:1px solid #24324a;border-radius:12px;padding:12px}}
.item b{{display:block;margin-bottom:4px;color:#fff}}
.item span{{color:#b7c7da;font-size:14px}}
.muted{{color:#8aa0b8}}
.doc{{white-space:pre-wrap;background:#0d1422;border:1px solid #24324a;border-radius:12px;padding:12px;color:#c5d4e6;font-size:12px;overflow:auto}}
a{{color:#6eb6ff}}
ol{{margin:0;padding-left:20px;color:#c5d4e6}}
li{{margin:6px 0}}
h3{{margin:14px 0 6px;font-size:13px;color:#9fd0ff}}
</style>
</head>
<body>
<div class="wrap">
  <div class="hero">
    <h1>DCE Solar Command — Live Packet for Sara</h1>
    <p>Auto-generated snapshot of Justin's live solar sales workspace: your script, rapport fundamentals, Illinois Shines official truth, and ROAM→DCE audio link.</p>
    <div class="badge">Generated {escape(STAMP)} · Ubuntu LLM brain · Lenovo / Roam front panel</div>
  </div>

  {section("What this is", '''
  <div class="list">
    <div class="item"><b>DCE Solar Command</b><span>Private live call coach for Illinois solar outbound. Script on screen, rapport rules, official Illinois Shines facts, closer packet, appointment latch, ROAM audio into the coach.</span></div>
    <div class="item"><b>What runs where</b><span>Ubuntu runs Solar Command + Ollama (LLM). Lenovo runs browser + Roam + headset. Phones/tablet can mirror the board with unlock token.</span></div>
    <div class="item"><b>What you can do</b><span>Review the exact live wording. Reply with any line changes and Justin reloads Command the same day.</span></div>
  </div>
  ''')}

  {section("Live sales script (currently loaded)", steps_html(sales))}
  {section("Fundamentals of Rapport (loaded)", steps_html(rapport))}
  {section("Illinois Shines — official program truth (loaded)", steps_html(shines))}

  {section("ROAM → DCE audio link", '''
  <ol>
    <li>Roam meeting open (not a PDF).</li>
    <li>JLab headset set in Roam.</li>
    <li>Chrome opens Solar Command.</li>
    <li>Click <b>LINK ROAM AUDIO</b> → share Roam window → enable system audio.</li>
    <li>Status must show <b>MIC+ROAM</b>, then START CALL. Ubuntu LLM coaches from the mixed audio.</li>
  </ol>
  ''')}

  {section("Source docs (auto-pulled)", docs_html)}

  {section("Official Illinois Shines source", '''
  <p><a href="https://illinoisshines.com/about/" target="_blank" rel="noopener">https://illinoisshines.com/about/</a></p>
  <p class="muted">Program truth is claim-gated: no invented savings %, ownership, or partnership language beyond approved vendor materials.</p>
  ''')}
</div>
</body>
</html>
"""


def ensure_invite() -> str:
    db: dict = {"tokens": {}}
    if ACCESS.exists():
        try:
            db = json.loads(ACCESS.read_text(encoding="utf-8"))
        except Exception:
            db = {"tokens": {}}
    db.setdefault("tokens", {})
    for tok, rec in list(db["tokens"].items()):
        if isinstance(rec, dict) and rec.get("access") == "dce-solar-packet" and rec.get("active", True):
            return tok
    tok = secrets.token_urlsafe(24)
    db["tokens"][tok] = {
        "name": "Sara V.",
        "email": "",
        "role": "Solar Coach Reviewer",
        "projectIds": [],
        "access": "dce-solar-packet",
        "active": True,
        "createdAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    ACCESS.write_text(json.dumps(db, indent=2), encoding="utf-8")
    return tok


def main() -> None:
    SCRIPTS.mkdir(exist_ok=True)
    html = build_packet()
    OUT.write_text(html, encoding="utf-8")
    print("packet", OUT)
    tok = ensure_invite()
    print("portal_token", tok)
    (SCRIPTS / "sara_portal_token.txt").write_text(tok, encoding="utf-8")
    (SCRIPTS / "SARA_SEND.txt").write_text(
        f"""SEND TO SARA — DCE Solar Command packet
Generated: {STAMP}

ATTACH in Roam/Teams:
  DCE_SARA_PACKET.html

OR live portal (same Wi-Fi / Tailscale):
  http://192.168.0.133:8787/portal/{tok}
  http://100.77.131.28:8787/portal/{tok}

PASTE MESSAGE:
Sara — auto packet of my live DCE Solar Command: your IL June script, rapport fundamentals, Illinois Shines official truth, and ROAM→DCE audio link. Open the HTML or the portal link and tell me any line changes.

Packet regenerates automatically when solar-command starts.
""",
        encoding="utf-8",
    )
    print("send_sheet_ok")


if __name__ == "__main__":
    main()
