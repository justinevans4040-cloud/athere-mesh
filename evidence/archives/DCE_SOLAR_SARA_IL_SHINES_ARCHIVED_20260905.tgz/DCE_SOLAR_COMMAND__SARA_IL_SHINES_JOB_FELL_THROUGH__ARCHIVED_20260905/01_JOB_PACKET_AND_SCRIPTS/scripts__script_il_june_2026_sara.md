# Script IL June 2026 (Sara) — LIVE

Source: Sara V. PDF "Script IL June 2026.pdf" (2026-08-21 screenshots).

## Open
Heeey [Homeowner]? Hey [Homeowner], this is [Your Name].

## Hook
We're doing some work over on [Street Name] as part of the IL Shines program — a new initiative being rolled out with ComEd and a company called LightReach.
Ask if they know IL Shines. Most people haven't — that's why you're calling.

## Reason
ComEd rates keep going up, grid demand is high, and qualified homes can get panels without a loan and without paying out of pocket for equipment.

## Frame
Not selling panels today. Checking if the home qualifies. If yes, schedule a quick visit for a side-by-side savings projection in writing.

## Simple version
LightReach installs and maintains. Homeowner doesn't own it, doesn't maintain it, isn't responsible if it breaks. They buy the power the panels produce at a lower rate than now.

Same house. Same power. Lower rate.

## Soft ask
Would you at least be open to checking if your home qualifies?
Then: highest bill / home purchase timing / book specialist / get bill text.
