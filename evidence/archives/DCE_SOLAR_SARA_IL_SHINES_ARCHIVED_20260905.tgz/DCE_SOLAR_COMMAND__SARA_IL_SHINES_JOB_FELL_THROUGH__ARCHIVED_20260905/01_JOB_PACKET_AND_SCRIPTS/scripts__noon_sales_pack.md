# NOON SALES PACK — ComEd / Illinois Shines / LightReach (from Magic Minutes 2026-08-21)

## Campaign
- Mostly ComEd; Ameren OK
- Teammates: Daniel Johnson, Marvin Manning (+2 Monday)
- Lead: Sara V. · Agent **32**
- Saturday dialing OK if team is on dialer together (flow dies with empty dialer)

## Simple pitch
Heeey [Name]? Hey [Name], this is Justin.
Work near [Street] as part of Illinois Shines — ComEd + LightReach.
Familiar with Illinois Shines? Most people aren’t — that’s why I’m calling.
Rates up, grid demand high, qualified homes can get panels with **no loan / no out-of-pocket for equipment**.
Not selling panels today — checking if the home qualifies → written side-by-side.
LightReach installs + maintains. You don’t own it, don’t maintain it, not responsible if it breaks.
You buy the power those panels produce at a lower rate.
**Same house. Same power. Lower rate.**
Soft ask: open to checking if the home qualifies?

## Ownership analogy
Utility pole outside / dish on the roof — you don’t buy those either. Cancel → they take it back.

## Proof
- illinoisshines.com PDF designees (Palmetto / LightReach)
- Google LightReach while you stay on the phone

## Six prequals (must clear or do not book)
1. Homeowner / decision path
2. House, townhome, or duplex (NO apt / condo / mobile)
3. Electric bill averages over $100/mo
4. Roof sun OK (Project Sunroof)
5. Mobile that receives texts (confirm SMS)
6. Email (confirm carefully — don’t shame them)

## Appointment quality
- Verification will torch weak sets (Jenny Stein lesson)
- Calendar: ComEd top-left · Name Firstletter-only uppercase · clean phone · notes for closer/verification
- Prefer :30 slots when possible

## Roam ops
- Pins in DM: Dialer, Calendar, Project Sunroof, Mic Test, Dialer troubleshooting
- Dialer = own Chrome window
- Calendar + Sunroof + Maps = one window
- Disposition every hangup · personal callback checkbox for YOUR agenda

## Objection model (close the box)
Acknowledge → short rebuttal → close box → keep walking the hallway.
Do not open every box.

## Fundamentals (Sara)
**First contact:** assume they’re already a customer · energy/body language transfers on phone · warmth of a regular.
**Build:** keep structure · rapport while qualifying · short rebuttals · only book when quality is green.

## DCE + Roam
Roam = floor. Solar Command = coach.
LINK ROAM AUDIO (Chrome) → share Roam + system audio → MIC+ROAM → START CALL.
