# Simple Direct Script (Sara) ? LIVE

Source: Sara V. PDF 2026-08-21. Ubuntu LLM / Solar Command active script.

## Open
Hi [Homeowner]? Hi [Homeowner], this is [Your Name]. I'm reaching out because we're working in the [CITY] area with ComEd's NET metering program.

## Why
We're helping take pressure off the electric grid ? bill inserts about possible outages and rate increases from data-center and AI demand.

## Partnership
ComEd and the state of Illinois teamed up with Lightreach so homeowners can produce their own power with solar and save up to 40% on electric bills.

## How it works
You don't buy the panels and you don't get them for free. Lightreach installs at no cost. You buy the power the panels produce at a lower rate than ComEd charges.

## Qualify
1. What is the most that you pay for power throughout the year?
2. How long ago did you buy your home?

## Close
Set a specialist follow-up for a side-by-side comparison so they can see savings in writing. Get bill usage bar + recent charges by text.
