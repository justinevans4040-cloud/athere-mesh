# DCE Solar Command — Operator Guide and Handoff

## What this is

DCE Solar Command is Justin's private live solar-sales workspace. It combines a readable sales script, flexible call stages, lead capture, local transcription, an Ollama-powered sales copilot, rebuttal paths, appointment guidance, notes, and a synchronized Ubuntu big-board display.

This is an operating tool, not a demo. Do not add sample leads, invented customer information, placeholder metrics, or unapproved claims.

## Where it runs

- Lenovo/Chrome control screen: `http://127.0.0.1:18787/`
- Ubuntu big board: `http://127.0.0.1:8787/`
- Ubuntu application: `/home/the_founder/forgefront/dce-solar-hardened-2026-08-20`
- Ubuntu host: `the_founder@ichabodcrane`
- Ollama model: `llama3.2:3b`
- Transcription: local `whisper.cpp` using `ggml-tiny.en.bin`

The Lenovo SSH tunnel forwards local port 18787 to Ubuntu port 8787. Ubuntu is configured to remain awake, and its dedicated Solar kiosk uses port 8787 directly.

## Current readiness

- Live server: working
- Lenovo-to-Ubuntu connection: working
- Ubuntu big-board kiosk: working
- Cross-screen active-lead synchronization: working, approximately one-second refresh
- Ollama rebuttal and next-move generation: working
- Local transcription endpoint: working
- Full readable sales script: working
- Numbered dynamic rebuttal paths: working
- Manual stage jumping: working
- Typed response analysis: working
- Direct operator voice commands: implemented
- Microphone plus Windows/ROAM system-audio capture: implemented; requires the browser permissions described below
- Automated call-flow/copilot tests: 35 passing

## Start here

1. On the Lenovo, open Chrome to `http://127.0.0.1:18787/`.
2. Confirm the top indicator says **ENGINE ONLINE**.
3. Confirm the Ubuntu big board shows Solar Command at `http://127.0.0.1:8787/`.
4. Enter the homeowner's real information. Do not enter test data into a live lead.
5. Enter the approved rep name and approved company/vendor identity. A work ID is not required.
6. Click **START LISTENING**.
7. Allow microphone access.
8. When Chrome asks what to share, select the ROAM window or the Windows screen carrying ROAM and enable **Share system audio**.
9. Begin the call. Use the large script panel and the live **SAY THIS NEXT** guidance.

## Headset and ROAM audio

The intended setup is:

- ROAM runs on the Lenovo.
- The Bluetooth or wired headset is selected as both ROAM input and ROAM output.
- Chrome receives the headset microphone.
- Chrome screen/system-audio sharing receives the customer's ROAM audio.
- Ubuntu performs transcription and Ollama analysis.

At the last hardware inspection, Windows exposed the Lenovo microphone array and Moises virtual audio, but did not yet expose the user's headset as a named input/output endpoint. Before a real call, confirm the headset appears under both Windows **Input** and **Output** and select it in ROAM.

## Using the call flow

Sales is not locked to a sequence. Every stage across the top is clickable:

`OPEN → EXPLAIN → QUALIFY → OBJECTION → SAVINGS BRIDGE → APPOINTMENT → BILL REQUEST → VERIFICATION → COMPLETE`

Jump forward or backward whenever the real conversation requires it. Selecting a stage immediately changes the readable script and guidance on both screens.

## Rebuttals

- Select the response/objection that matches what the homeowner said.
- The large script switches to a numbered five-step rebuttal path.
- If the objection is not listed, type the homeowner's exact words into the copilot box and press **ANALYZE**.
- The copilot returns what to say, what to determine next, and how to return to qualification or booking.
- If another objection follows, type or speak it and repeat. The path is designed to stay fluid.

## Talking directly to the sales agent

While listening, address the agent with a wake phrase:

- “Copilot, what should I ask next?”
- “Copilot, give me a rebuttal for that.”
- “Ollama, what information am I missing?”
- “Agent, help me move this toward an appointment.”

Wake-phrase speech is treated as an operator command, not homeowner speech. The response appears in the copilot answer area and mirrors to the big board.

## Notes and form updates

The copilot identifies key metrics, motivations, hot-button issues, objections, and appointment leverage. Suggested field changes require operator confirmation. Confirmed notes append to existing notes rather than replacing them. Nonblank operator-entered fields are not overwritten.

Use **SAVE** during the call. Use **COPY HANDOFF** when sending the complete lead context to the closer. Use **CLEAN SLATE** only after the current lead is saved or handed off.

## Quick pre-call test

1. Open both screens and verify **ENGINE ONLINE**.
2. Click **START LISTENING** and grant microphone plus ROAM system-audio sharing.
3. Say: “Copilot, what should I ask first?” Confirm an answer appears on both screens.
4. Play or speak: “I'm not interested; I need to think about it.” Confirm transcription and a numbered rebuttal appear.
5. Type a temporary phrase into a non-lead field only if needed for testing; do not save fabricated lead data.
6. Click **STOP** when the test is complete.

## Immediate next validation

The next operator or agent should begin here:

1. Connect/pair the user's preferred headset and verify its named Windows input and output endpoints.
2. Select those endpoints inside ROAM.
3. Perform one private test call through ROAM.
4. Verify the transcript contains both the operator and remote caller while audio remains in the headset.
5. Verify a spoken objection triggers the on-screen rebuttal and big-board alert/path.
6. Verify direct “Copilot…” commands are separated from homeowner speech.
7. Fix any audio-device selection or level issue found during that real two-sided test; do not redesign the application.

## Operational rules

- Never add fake leads or fake business data.
- Never require the operator to say a work ID.
- Never lock the operator into a linear sales sequence.
- Never open duplicate Solar windows; update the existing Lenovo Chrome window and the single Ubuntu kiosk.
- Lenovo and Ubuntu use different local URLs: port 18787 on Lenovo, port 8787 on Ubuntu.
- The app is delivered network-only; do not reintroduce an offline service-worker cache.
- Preserve real state and access records when testing.

## Recovery checks

- Lenovo health: `http://127.0.0.1:18787/api/health`
- Ubuntu health: `http://127.0.0.1:8787/api/health`
- If Lenovo is offline but Ubuntu is healthy, restore the SSH tunnel from 18787 to Ubuntu 8787.
- If the big board is orange/offline, verify it uses Ubuntu port 8787, not Lenovo port 18787.
- If Chrome appears stale, the server should return `Cache-Control: no-store` and `Clear-Site-Data: "cache"` for HTML.

