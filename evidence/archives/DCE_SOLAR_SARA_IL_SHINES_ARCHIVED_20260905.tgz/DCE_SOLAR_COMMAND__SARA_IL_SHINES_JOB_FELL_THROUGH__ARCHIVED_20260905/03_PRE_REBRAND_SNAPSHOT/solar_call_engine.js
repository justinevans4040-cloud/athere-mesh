(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  if(root) root.SolarCallEngine=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';

  const CLAIMS = Object.freeze({
    utility_affiliation:{status:'verify',label:'Utility / program affiliation',fallback:'Describe only the relationship confirmed in the current approved vendor/program materials.'},
    local_work:{status:'verify',label:'Nearby work / local project reference',fallback:'Only say work is happening near the homeowner when that local project reference has been verified.'},
    savings_40:{status:'verify',label:'Up to 40% cheaper',fallback:'Use only the customer-specific savings shown in the approved proposal or disclosure.'},
    savings_50:{status:'verify',label:'Up to 50% cheaper',fallback:'Use only the customer-specific savings shown in the approved proposal or disclosure.'},
    state_federal_funding:{status:'verify',label:'State/federal funding covers cost',fallback:'Describe equipment, installation, incentives, and payment obligations only from the current approved offer documents.'},
    no_monthly_payment:{status:'verify',label:'No monthly payment',fallback:'Do not promise zero ongoing payment; use the current agreement/disclosure to explain the customer payment structure.'},
    roof_warranty:{status:'verify',label:'Roof warranty coverage',fallback:'Record the roof concern and route the warranty question to the specialist or current written warranty terms.'},
    transfer_terms:{status:'verify',label:'Transfer when moving/selling',fallback:'Use only the transfer terms in the current customer agreement.'},
    rate_hike_18:{status:'verify',label:'18% rate-hike attribution',fallback:'Use a current, verified source and exact supported figure before quoting a rate increase.'}
  });

  const ACTIONS = Object.freeze({
    OPEN:['program_unaware','aware_passive','aware_active','already_shopping','do_not_contact'],
    AWARENESS:['program_unaware','aware_passive','aware_active','already_shopping','do_not_contact'],
    EXPLAIN:['explanation_complete','already_shopping','research_trust','roof_old','roof_warranty','payment_structure','household_succession','general_resistance','do_not_contact'],
    QUALIFY:['qualification_update','roof_old','roof_warranty','research_trust','decision_maker','bill_unavailable','moving_transfer','term_duration','payment_structure','household_succession','general_resistance','ready_for_savings','ready_for_appointment','do_not_contact'],
    OBJECTION:['return_to_qualify','ready_for_savings','ready_for_appointment','do_not_contact'],
    SAVINGS_BRIDGE:['ready_for_appointment','research_trust','do_not_contact'],
    APPOINTMENT:['appointment_booked','research_trust','do_not_contact'],
    BILL_REQUEST:['bill_requested','bill_received','bill_unavailable','do_not_contact'],
    VERIFICATION:['bill_received','verification_complete','do_not_contact'],
    COMPLETE:[],
    TERMINATED:[]
  });

  const ACTION_LABELS = Object.freeze({
    program_unaware:'Has not heard of program',
    aware_passive:'Has heard of it',
    aware_active:'Already understands / skip pitch',
    already_shopping:'Already shopping solar',
    explanation_complete:'Move to qualification',
    qualification_update:'Save qualification',
    roof_old:'Older roof concern',
    roof_warranty:'New roof / warranty concern',
    research_trust:'Needs research / trust concern',
    decision_maker:'Spouse / decision maker',
    bill_unavailable:'Bill unavailable',
    moving_transfer:'Moving / transfer question',
    term_duration:'Term / duration question',
    payment_structure:'Payment / monthly obligation concern',
    household_succession:'Household / succession concern',
    general_resistance:'General resistance',
    return_to_qualify:'Return to qualification',
    ready_for_savings:'Bridge to savings report',
    ready_for_appointment:'Ready to book',
    appointment_booked:'Appointment booked',
    bill_requested:'Bill requested',
    bill_received:'Bill received',
    verification_complete:'Verification complete',
    do_not_contact:'Stop / do not contact'
  });

  const OBJECTION_EVENTS = new Set([
    'already_shopping','roof_old','roof_warranty','research_trust','decision_maker','bill_unavailable',
    'moving_transfer','term_duration','payment_structure','household_succession','general_resistance'
  ]);

  function now(){return new Date().toISOString();}
  function uniq(arr){return Array.from(new Set(arr||[]));}
  function deepClone(value){return JSON.parse(JSON.stringify(value));}
  function text(value){return value==null?'':String(value);}
  function hasValue(value){return !(value===undefined||value===null||String(value).trim()===''||value===false);}

  function createSession(input={}){
    const startedAt=input.startedAt||now();
    return {
      id:input.id||`solar_${Math.random().toString(36).slice(2,9)}`,
      leadId:input.leadId||'',
      repName:input.repName||'',
      repId:input.repId||'',
      stage:'OPEN',
      branch:'',
      data:{},
      objections:[],
      unresolved:[],
      history:[{type:'session_started',event:'session_started',stage:'OPEN',time:startedAt,payload:{}}],
      disposition:'',
      startedAt,
      updatedAt:startedAt,
      completedAt:''
    };
  }

  function record(next,type,event,payload){
    next.updatedAt=now();
    next.history.push({type,event,stage:next.stage,branch:next.branch||'',time:next.updatedAt,payload:deepClone(payload||{})});
    return next;
  }
  function mergeData(next,payload){next.data=Object.assign({},next.data||{},payload||{});}
  function addObjection(next,name,unresolved=true){
    next.objections=uniq([...(next.objections||[]),name]);
    if(unresolved) next.unresolved=uniq([...(next.unresolved||[]),name]);
  }
  function isAllowed(stage,event){return (ACTIONS[stage]||[]).includes(event);}

  function applyEvent(session,event,payload={}){
    const next=deepClone(session||createSession());
    const e=text(event);
    const p=deepClone(payload||{});

    if(!Object.prototype.hasOwnProperty.call(ACTION_LABELS,e)) return record(next,'invalid_event',e,p);
    const eventStage=next.stage==='OBJECTION'&&!next.branch&&OBJECTION_EVENTS.has(e)?'QUALIFY':next.stage;
    if(!isAllowed(eventStage,e)) return record(next,'invalid_transition',e,p);

    switch(e){
      case 'program_unaware': next.stage='EXPLAIN'; next.branch='program_unaware'; break;
      case 'aware_passive': next.stage='EXPLAIN'; next.branch='aware_passive'; break;
      case 'aware_active': next.stage='OBJECTION'; next.branch='already_aware_active'; addObjection(next,'already_aware_active',false); break;
      case 'already_shopping': next.stage='OBJECTION'; next.branch='competitor_comparison'; addObjection(next,'competitor_comparison',false); break;
      case 'explanation_complete': next.stage='QUALIFY'; next.branch=''; break;
      case 'qualification_update': next.stage='QUALIFY'; mergeData(next,p); next.branch=''; break;
      case 'roof_old': next.stage='OBJECTION'; next.branch='roof_old'; mergeData(next,p); addObjection(next,'roof_old',true); break;
      case 'roof_warranty': next.stage='OBJECTION'; next.branch='roof_warranty'; mergeData(next,p); addObjection(next,'roof_warranty',true); break;
      case 'research_trust': next.stage='OBJECTION'; next.branch='research_trust'; mergeData(next,p); addObjection(next,'research_trust',true); break;
      case 'decision_maker': next.stage='OBJECTION'; next.branch='decision_maker'; mergeData(next,p); addObjection(next,'decision_maker',false); break;
      case 'bill_unavailable': next.stage='OBJECTION'; next.branch='bill_unavailable'; mergeData(next,p); addObjection(next,'bill_unavailable',false); break;
      case 'moving_transfer': next.stage='OBJECTION'; next.branch='moving_transfer'; mergeData(next,p); addObjection(next,'moving_transfer',true); break;
      case 'term_duration': next.stage='OBJECTION'; next.branch='term_duration'; mergeData(next,p); addObjection(next,'term_duration',true); break;
      case 'payment_structure': next.stage='OBJECTION'; next.branch='payment_structure'; mergeData(next,p); addObjection(next,'payment_structure',true); break;
      case 'household_succession': next.stage='OBJECTION'; next.branch='household_succession'; mergeData(next,p); addObjection(next,'household_succession',true); break;
      case 'general_resistance': next.stage='OBJECTION'; next.branch='general_resistance'; mergeData(next,p); addObjection(next,'general_resistance',false); break;
      case 'return_to_qualify': next.stage='QUALIFY'; next.branch=''; break;
      case 'ready_for_savings': next.stage='SAVINGS_BRIDGE'; next.branch=''; break;
      case 'ready_for_appointment': next.stage='APPOINTMENT'; next.branch=''; break;
      case 'appointment_booked': next.stage='BILL_REQUEST'; next.branch=''; mergeData(next,p); next.disposition='Appointment Booked'; break;
      case 'bill_requested': next.stage='VERIFICATION'; next.branch=''; mergeData(next,p); next.data.billRequested=true; break;
      case 'bill_received': next.stage='VERIFICATION'; next.branch=''; mergeData(next,p); next.data.billReceived=true; break;
      case 'verification_complete': next.stage='COMPLETE'; next.branch=''; mergeData(next,p); next.data.verificationStatus='Complete'; next.disposition='Appointment Ready'; next.completedAt=now(); break;
      case 'do_not_contact': next.stage='TERMINATED'; next.branch='do_not_contact'; next.disposition='Do Not Contact'; next.completedAt=now(); break;
    }
    return record(next,OBJECTION_EVENTS.has(e)||e==='aware_active'?'branch':'transition',e,p);
  }

  function fill(template,ctx){return template.replace(/\{(\w+)\}/g,(_,key)=>text(ctx[key]));}

  
  function withRapport(g, stage){
    const checklist=[
      'Name 3x in first 2 minutes (hello, bridge, first question)',
      'Match pace and volume',
      'Mirror last 2-3 words once, then silence',
      'Match energy before the pitch',
      'Listen fully to IL Shines recognition answer before explaining LightReach'
    ];
    if(stage==='OPEN' || stage==='EXPLAIN'){
      g.rapportChecklist=checklist;
      g.objective=(g.objective||'')+' | Rapport: name 3x max, pace match, one mirror, listen before explain.';
    }
    return g;
  }

  function branchGuidance(branch){
    const map={
      already_aware_active:{objective:'Stop the spiel and answer the prospect’s actual question.',recommendedLine:'Absolutely — go ahead. What is the main thing you want to compare or understand?',observedReference:'Nancy stopped when Brandon said he already knew the program and moved directly to his comparison question.'},
      competitor_comparison:{objective:'Find what “different” means to this prospect, answer only what is verified, then bridge back to the savings report.',recommendedLine:'That’s a great question. What matters most to you in comparing the companies — installation, maintenance, the numbers, or something else?',observedReference:'Nancy answered Brandon from the homeowner’s point of view, then returned to putting a savings report together.'},
      roof_old:{objective:'Capture roof age/replacement horizon and route eligibility to the specialist; do not invent a workaround.',recommendedLine:'That’s definitely something we need them to look at before anything moves forward. How old is the roof, roughly?',observedReference:'Ryan raised an older-roof concern; Nancy kept the appointment alive without inventing a technical answer.'},
      roof_warranty:{objective:'Capture roof installer, age, and warranty concern. Use written warranty terms or the specialist for the answer.',recommendedLine:'Sure. How recently was the roof installed, and who installed it? I’ll make sure that warranty question is specifically noted for the specialist.',observedReference:'Arthur’s first real objection was that panel installation could interfere with the warranty on his newer roof.'},
      research_trust:{objective:'Respect the research concern, capture the specific question, and make the appointment about getting verifiable information.',recommendedLine:'That makes sense. What is the biggest thing you want to verify or research? I’ll make sure the specialist addresses that directly.',observedReference:'Arthur wanted more research after hearing negative solar experiences; the successful next objective was more information, not a forced commitment.'},
      decision_maker:{objective:'Identify everyone who needs to be present for the savings discussion.',recommendedLine:'Who else is involved in decisions about the home’s energy? Let’s pick a time when everyone who needs the numbers can be there.'},
      bill_unavailable:{objective:'Keep the appointment and create a specific follow-up for the bill instead of losing momentum.',recommendedLine:'No problem. We can keep the appointment in place and make the bill the next follow-up item so the savings report can be prepared.'},
      moving_transfer:{objective:'Do not improvise transfer terms. Capture the question and answer from the current agreement.',recommendedLine:'That’s an agreement-specific question. I’m noting it so the specialist can show you the exact transfer language in writing.',warning:'Transfer terms are gated until verified from the current customer agreement.'},
      term_duration:{objective:'Do not guess the agreement or coverage term. Route to the written agreement.',recommendedLine:'I don’t want to guess at the term. I’m noting that so the specialist can show you the exact duration and coverage language in writing.',warning:'Term/duration is agreement-specific.'},
      payment_structure:{objective:'Separate this offer from prior payment assumptions without promising terms that are not verified.',recommendedLine:'That’s important. I don’t want to misstate the payment structure — I’m flagging it so the exact payment obligations can be shown to you in writing.',observedReference:'Arthur’s prior solar experience included concern about ongoing monthly payments.',warning:'Payment structure is agreement-specific and remains claim-gated.'},
      household_succession:{objective:'Preserve the household or succession concern for the specialist; do not reduce it to a generic price objection.',recommendedLine:'I understand why that matters. I’m noting the long-term household concern so the specialist can address the exact obligations and what happens over time in writing.',observedReference:'Arthur raised a long-term family concern tied to who could be responsible after him.'},
      general_resistance:{objective:'Lower pressure, identify the real concern, then either continue qualification or exit cleanly.',recommendedLine:'Understood. I’m not asking you to make a decision right now — what part is giving you the most hesitation?'}
    };
    return map[branch]||{objective:'Answer the prospect’s question briefly, then return to the next qualification objective.',recommendedLine:'Got it. What is the main thing you want answered before we keep going?'};
  }

  function qualificationGuidance(data={}){
    if(!hasValue(data.highestBill)) return {objective:'Establish whether the usage level is worth a savings review.',recommendedLine:'What is the most that you pay for power throughout the year?',observedReference:'Nancy moved directly from the brief explanation into the highest-bill question.'};
    if(!hasValue(data.averageBill)) return {objective:'Get the yearly pattern and a realistic average bill.',recommendedLine:'Are your bills mostly high in the summer, winter, or both? If you averaged the year out, what would a normal month look like?',observedReference:'With Ryan, Nancy followed the $518 high bill by asking when bills run high and estimating the yearly average.'};
    if(!hasValue(data.utility)) return {objective:'Confirm the utility before the savings handoff.',recommendedLine:'And just to make sure I have it right — are you with ComEd, Ameren, or another utility?'};
    if(!hasValue(data.sunExposure)) return {objective:'Check whether the roof gets usable sun and note material shade.',recommendedLine:'How is the sun exposure on the roof — mostly open sun, or do you have trees shading it? I can check the property view too.',observedReference:'Nancy asked Ryan about sun exposure and then checked the property herself.'};
    if(!hasValue(data.futureLoad)) return {objective:'Capture planned load changes that could materially change usage.',recommendedLine:'Any plans for something that would change the electric load — an EV, hot tub, pool, or anything similar?'};
    if(!hasValue(data.roofConcern)&&!hasValue(data.roofAgeYears)) return {objective:'Screen for a roof-age or warranty issue before booking.',recommendedLine:'Any roof concern I should flag — an older roof, a newer-roof warranty, or anything else they should look at?'};
    return {objective:'Core qualification is captured. Move to the savings-report bridge or book if the homeowner is ready.',recommendedLine:'That gives me what I need for the qualification side. The next step is to put the numbers together and show you the comparison in writing.'};
  }

  function getGuidance(session,context={}){
    const s=session||createSession();
    const ctx=Object.assign({},s.data||{},context||{}, {
      repName:context.repName||s.repName||'',
      repId:context.repId||s.repId||'',
      leadName:context.leadName||'',
      companyIdentity:context.companyIdentity||''
    });
    let g;
    switch(s.stage){
      case 'OPEN':
        if(!ctx.repName){ ctx.repName='Justin'; }
        if(!ctx.companyIdentity){ ctx.companyIdentity='LightReach / Illinois Shines'; ctx.companyIdentityApproved=true; }
        if(false && (!ctx.companyIdentityApproved||!ctx.companyIdentity||!ctx.repName)){
          g={objective:'Complete the approved outbound identity before beginning the call.',recommendedLine:'Set the rep name and approved company/vendor identity, then confirm that identity is approved before making an outbound call.',warning:'The engine will not invent or silently approve the caller identity.'};
        }else if(ctx.localWorkVerified===true&&ctx.street){
          g={objective:'Build rapport first (name 3x, pace match, one mirror), identify yourself with verified local/program context, and learn whether the homeowner already knows the program.',recommendedLine:fill('Hey — it’s {repName}. We’re doing some work over on {street} with the Illinois Shines program. Have you heard of Illinois Shines?',ctx),observedReference:'Nancy and Jeff both used the homeowner’s name, a nearby street/road reference, and a recognition question.',warning:'Use the nearby-work wording only when the local project reference is verified.'};
        }else{
          g={objective:'Build rapport first (name 3x, pace match), identify yourself, and learn whether the homeowner already knows the program without inventing a nearby-work claim.',recommendedLine:fill('Hey — it’s {repName}. I’ll be quick. I’m calling about the Illinois Shines program with ComEd and LightReach. Have you heard of Illinois Shines?',ctx),warning:'Utility/program affiliation remains claim-gated; use only the relationship approved by the current vendor/program materials.'};
        }
        break;
      case 'EXPLAIN':
        g={objective:'Only after they answer the recognition question: give just enough context to earn qualification. Keep it brief. Match their energy.',recommendedLine:'You’re not making any decisions today. I’m just checking whether the home may qualify. If it does, the next step is a side-by-side savings report so you can see the numbers in writing.',observedReference:'Nancy: “You’re not making any decisions today. I’m just… checking to see if your home even qualifies.”',warning:'Savings percentages, funding structure, and utility/LightReach affiliation remain gated until verified.'};
        break;
      case 'QUALIFY': g=qualificationGuidance(s.data||{}); break;
      case 'OBJECTION': g=branchGuidance(s.branch); break;
      case 'SAVINGS_BRIDGE': g={objective:'Turn interest into a low-pressure reason for the follow-up appointment.',recommendedLine:'What we can do is put a savings report together and walk you through the numbers. If it makes sense, great. If not, at least you know what your options are.',observedReference:'Both Nancy calls used the savings report as the bridge back to the appointment objective.'}; break;
      case 'APPOINTMENT': g={objective:'Book the next step while the prospect is still engaged, and state the actual appointment format.',recommendedLine:'I can get that set up. I’ll make sure we book it as the actual format — phone, Zoom, or in-person — and then find the time that works best.',warning:'Do not describe the appointment as in-person if the scheduled appointment is actually phone or Zoom.'}; break;
      case 'BILL_REQUEST': g={objective:'Get the bill/usage screenshot needed to prepare the report without reopening the sale.',recommendedLine:'So the savings report can be ready before the appointment, can you reply to the text with the usage bar graph and your most recent charges?'}; break;
      case 'VERIFICATION':
        g=s.data?.billReceived
          ? {objective:'Protect the appointment and complete the remaining verification.',recommendedLine:'The bill is in. The remaining step is the verification call so they can confirm the usage and roof details before the appointment.'}
          : {objective:'Keep the appointment protected while the bill screenshot and verification are still outstanding.',recommendedLine:'You’re booked. I still need the bill screenshot for the savings report, and then the verification call can confirm the usage and roof details.'};
        break;
      case 'COMPLETE': g={objective:'Appointment is ready. Preserve notes and unresolved questions for the closer.',recommendedLine:'Call flow complete — review the notes and unresolved items before handoff.'}; break;
      case 'TERMINATED': g={objective:'End the call and do not continue selling.',recommendedLine:'End the call now and keep the lead marked Do Not Contact.'}; break;
      default: g={objective:'Return to a known call stage.',recommendedLine:'Choose the next verified call step.'};
    }
    return withRapport(Object.assign({stage:s.stage,branch:s.branch||'',requiredFields:getRequiredFields(s),actions:getAvailableActions(s)},g), s.stage);
  }

  function getAvailableActions(session){
    const stage=(session&&session.stage)||'OPEN';
    return (ACTIONS[stage]||[]).map(id=>({id,label:ACTION_LABELS[id]||id}));
  }

  function getRequiredFields(session){
    const s=session||{stage:'OPEN',branch:'',data:{}};
    if(s.stage==='OPEN') return ['companyIdentity','companyIdentityApproved','repName','leadName'];
    if(s.stage==='EXPLAIN') return [];
    if(s.stage==='QUALIFY'){
      const d=s.data||{}, fields=['highestBill','averageBill','utility','sunExposure','futureLoad'];
      if(!hasValue(d.roofConcern)&&!hasValue(d.roofAgeYears)) fields.push('roofConcern');
      return fields;
    }
    if(s.stage==='OBJECTION'){
      if(s.branch==='roof_old') return ['roofAgeYears','roofConcern'];
      if(s.branch==='roof_warranty') return ['roofAgeYears','roofInstaller','roofConcern'];
      if(s.branch==='household_succession') return ['householdConcern'];
      return [];
    }
    if(s.stage==='APPOINTMENT') return ['appointmentType','appointmentDate','appointmentTime','email','phone'];
    if(s.stage==='BILL_REQUEST') return ['billReceived'];
    if(s.stage==='VERIFICATION') return s.data?.billReceived?['verificationStatus']:['billReceived','verificationStatus'];
    return [];
  }

  function getClaimStatus(claimId){
    const claim=CLAIMS[claimId];
    if(!claim) return {id:claimId,status:'unknown',label:claimId,fallback:'No approved claim is registered for this topic.'};
    return Object.assign({id:claimId},deepClone(claim));
  }

  return Object.freeze({createSession,applyEvent,getGuidance,getAvailableActions,getRequiredFields,getClaimStatus});
});
