# ForgeFront Solar Command — deploy

**Live (Ubuntu Ichabod):** `/home/the_founder/forgefront/solar-command/`  
**GitHub:** https://github.com/justinevans4040-cloud/forgefront-solar-command

## Upgrade flow

1. Edit and commit on GitHub (or push from dev machine).
2. On Ichabod:
   ```bash
   cd /home/the_founder/forgefront/solar-command
   git pull
   systemctl --user restart solar-command.service
   ```
3. Open from desktop icon — launcher reads `buildId` from `/api/health` so Firefox always loads the current HTML.

## One copy rule

Do not keep dated folders, zip drops, or `.bak` trees on disk. Old builds live in git history on GitHub only.
