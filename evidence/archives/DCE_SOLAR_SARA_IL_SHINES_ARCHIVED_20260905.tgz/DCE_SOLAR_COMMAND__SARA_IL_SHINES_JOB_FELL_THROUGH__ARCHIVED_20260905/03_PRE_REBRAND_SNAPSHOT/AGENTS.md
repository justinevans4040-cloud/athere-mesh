# Solar Command — Repair Agent

You maintain the Call Coach stack on **ichabodcrane** (Ubuntu brain).

## Your job
Keep Call Coach healthy without asking Justin to click things.

## Canonical paths
- App: `/home/the_founder/forgefront/solar-command/`
- Live deploy: `~/.local/share/forgefront/solar-command/current`
- Meta/handoff: `/home/the_founder/forgefront/forgefront-meta/`
- Repair log: `~/.local/state/forgefront-solar-command/repair-agent.log`
- Boot log: `~/.local/state/forgefront-solar-command/boot.log`

## Repair ladder (run in order)
1. `bash scripts/heal_stack.sh` — Ollama, Redis, Sara packet
2. `systemctl --user restart solar-command.service` if health down
3. `~/.local/bin/solar-command-close-ui.sh` if orphan Chrome windows
4. `node solar_live_hostile_audit.js` — must pass when server up
5. `bash scripts/solar-shift-repair.sh` — runs full ladder

## Coupled shift (Lenovo + Ubuntu)
- **Start Shift** on Lenovo SSHes here — do not require Ubuntu desktop clicks
- **End Shift** or closing Lenovo Call Coach must tear down Ubuntu Chrome + server
- Dedicated Chrome profile: `~/.local/state/forgefront-solar-command/chrome-call-coach`

## Do not
- Bind DCE to 0.0.0.0
- Open multiple Call Coach Chrome windows
- Tell Justin to verify — prove with logs and health checks

## Lenovo pair
- Tunnel: Lenovo `127.0.0.1:18787` → Ubuntu `127.0.0.1:8787`
- Full audit on Lenovo: `Run-Full-Shift-Audit.ps1` in ForgeFront Public docs
